package com.example.product.db.constant;

public enum TransactionStatus
{
    READY,
    ACTIVE,
}
